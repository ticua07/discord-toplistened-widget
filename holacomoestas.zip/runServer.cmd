bun ./server.js
pause